using UnityEngine;
using System.Collections;

public interface IEventParameterBase
{
    
}
